# CineStock — instrucciones de la sesión del 27/10/2026

> Documento de apoyo. La regla sigue siendo: **el robot NUNCA pulsa Guardar**.
> Tú revisas el pedido en Chrome y guardas a mano.

> 🧪 **ACLARACIÓN DE LA ENCARGADA (27/10/2026, 19:30):** el pedido de **100
> líneas ES SOLO UNA PRUEBA DE DIAGNÓSTICO**, no un pedido real. Su única
> finalidad es **detectar qué productos fallan en el ERP y qué hay que
> cambiar**. No hay que corregir las líneas a mano ni pulsar Guardar en él;
> se puede descartar. Lo que vale es su **informe**. El pedido real es el de
> **146 líneas**, que se lanzará cuando el catálogo esté limpio.

> ✅ **ESTADO DE LA SUBIDA (27/10/2026): COMPLETO.** En la rama
> `arena/67d0fffb-pedidos-conway` están el robot **v6b** (el archivo exacto del
> PC de la encargada, verificado con `comprobar version robot.py`), el catálogo
> corregido, el receptor, los parcheadores y el comprobador.
> `data/` y `.env` siguen FUERA de Git. Ya se puede hacer `git pull` en el PC
> del cine.

---

## 1. Qué estaba pasando (causa real de los 4 rechazos)

No era culpa del robot v6b. Era un problema de datos:

* La pantalla **CATÁLOGO SUPERMAESTRO** (`src/ui/catalogo.py`) guardaba en
  `data/supermaestro.json`.
* El receptor (`src/receptor.py`) leía `data/supermaestro_flow.json`, que
  **no existía**. Y si faltaba, se tragaba el error en silencio
  (`except: return data`).
* Resultado: los pedidos llegaban al robot con los `idErp` / `umErp` viejos
  que traía Flow, y el ERP rechazaba 4 artículos.

Además, en el informe `src/errores_pedido_20261027_143749.txt` las filas 33 a
100 NO son errores de datos: en la fila 33 aparece
`invalid session id: session deleted as the browser has closed the connection`.
**Chrome se desconectó ahí** (portátil suspendido). De ahí la cascada de
"No se localizó su fila vacía en el grid".

---

## 2. Correcciones del catálogo (verificadas en el ERP)

Archivo versionado: **`src/recursos/correcciones_erp.json`**.
Tiene **prioridad** sobre `data/supermaestro.json` y `data/supermaestro_flow.json`.

| Artículo | ID VISTA | Antes | Después | Estado |
|---|---|---|---|---|
| (CI) Bolsa Asa Papel | 9580 | `1003020091` / `IAH` | `1003020091` / **`ICG`** | ⚠️ UM pendiente de confirmar con la lupa de `*UM` |
| (CI) Cuchara Madera | 8969 | `1003020087` / `IDV` | **`1003020096` / `GDE`** | ✅ Verificado |
| (CI) Tapa Vaso Mediana | 122 | `1003020096` / `GDE` | **`1003020030` / `CJA`** | ✅ Verificado |
| (CI) Tapa Vaso Pequeña/Infantil | 123 | `1003020031` / `IDZ` | *(sin sustituir)* | ❌ **Ya no existe en el ERP** |
| (CI) Divisor Palomitas Universal | 9816 | `1003020099` / `GDE` | `1003020099` / `GDE` | ✅ Verificado (GDE sí vale aquí) |

**Ojo con dos confusiones que ya hemos resuelto:**

* `1003020096` es **Cuchara Madera**, NO una tapa.
* El código original de Tapa Vaso Mediana (`1003020030`) **era correcto**; lo
  que estaba mal era la UM (`GDE` en vez de `CJA`).
* Las UM son **por artículo**: que `GDE` valga para el Divisor Palomitas
  (`1003020099`) no significa que valga para una tapa.

**Tapa Infantil:** decisión de la encargada = **"LA DEJAMOS"**. La línea se
queda en el pedido de 100 líneas; el robot v6b la anotará como incidencia real
y seguirá hasta la 100. No se inventa un código sustituto.

### ⚠️ Regla crítica: SOLO se corrigen esos artículos

El 27/10/2026 por la tarde detectamos que aplicar el catálogo **entero**
(304 productos) a los pedidos cambiaba también las UM de familias con
variantes que comparten `ID VISTA`:

```
línea 71 | Kit Kat Normal   | HSI -> GBC   (MAL)
línea 81 | Skittle Frutas   | HWD -> HWC   (MAL)
```

Esas UM venían bien de Flow. Por eso `src/catalogo_erp.py` ahora aplica
**únicamente** las correcciones de `src/recursos/correcciones_erp.json`.
Todo lo demás se deja exactamente como lo mandó Flow. El catálogo completo
fusionado se sigue sirviendo en `GET /supermaestro` para que Flow pueda
descargarlo, pero **no se usa para reescribir pedidos**.

Al ejecutar `regenerar_pedido.py` deben aparecer **solo 3 líneas corregidas**
por archivo (Bolsa Asa Papel, Cuchara Madera, Tapa Vaso Mediana). Si aparece
cualquier otra línea, **no lances el robot** y avisa.

### 🛡️ Familias blindadas

A petición de la encargada, estas familias y **todos sus "hijos"** están
protegidos por nombre: **Kit Kat, Skittle, Haribo 100, Estuchados 3.90,
Helados y Kojack**.

La lista está en `src/recursos/correcciones_erp.json` →
`FAMILIAS_PROTEGIDAS`. Ni `regenerar_pedido.py`, ni `src/receptor.py`, ni el
catálogo `GET /supermaestro` pueden cambiar una línea cuyo nombre contenga
una de esas palabras. Es un seguro doble: aunque alguien vuelva a cargar el
catálogo entero, esas UM no se tocan.

> **Ortografía real del pedido (27/10/2026):** los productos se escriben
> **`Fiesta Kojak Cereza` / `Fiesta Kojak Cola`**, con **una sola c**.
> La lista incluye las dos grafías (`Kojak` y `Kojack`) para que las líneas
> 72 y 73 queden blindadas. `src/verificar_pedido.py` lee esa misma lista
> (una sola fuente de verdad) y las muestra en su salida.

Además, al aplicar una corrección al catálogo solo se modifica la fila cuyo
**nombre** coincide. Antes se modificaban *todas* las filas con el mismo
`ID VISTA`, que es justo lo que estropeaba a los "hijos" de una familia.

`regenerar_pedido.py` imprime una línea de control, por ejemplo:

```
    familias BLINDADAS intactas: Haribo (3), Helado (2), Kit Kat (4), Kojack (1), Skittle (2)
```

### ❌ NO ejecutar «aplicar parche v6.py»

Ese parcheador es la versión **anterior** a la v6b. Trae las mismas funciones
de anclado/bloques, pero con una diferencia crítica: **se PARA en la primera
línea que falle**. Con la Tapa Infantil en la línea 30, no llegaría a la 100.
La v6b, en cambio, **anota la incidencia y SIGUE**.

`src/robot_erp.py` ya contiene todo el parche v6 **y** el arreglo "b". Si se
ejecutara ese parcheador sobre él, diría «El parche v6 ya está aplicado» (no
haría nada); si se ejecutara sobre un robot más antiguo, lo **desactualizaría**.
Por tanto: no se sube a Git y no se ejecuta.

---

## 3. Archivos nuevos / cambiados en esta sesión

| Archivo | Qué es |
|---|---|
| `src/robot_erp.py` | Robot **v6b** (ancla filas, bloques de 20, anota el error y SIGUE). Nunca guarda. |
| `src/aplicar parche v5.py` | Parcheador v5 (paginación, una a una). |
| `src/aplicar parche v6b.py` | Parcheador v6b (bloques de 20 + anotar y seguir). |
| `src/devolver v6.py` | Utilidad de emergencia para volver a v6. |
| `src/comprobar version robot.py` | Comprobador: debe decir **`v6b`**. |
| `src/comprobar_version_robot.py` | Alias sin espacios del anterior. |
| `src/catalogo_erp.py` | **NUEVO.** Unifica catálogos y aplica las correcciones ERP. |
| `src/recursos/correcciones_erp.json` | **NUEVO.** Las 5 correcciones verificadas (SÍ en Git). |
| `src/receptor.py` | **CAMBIADO.** Ya no falla en silencio; aplica `catalogo_erp`. |
| `src/ui/catalogo.py` | **CAMBIADO.** «Guardar» escribe los DOS archivos `data/*.json`. |
| `src/regenerar_pedido.py` | **NUEVO.** Reaplica SOLO las correcciones ERP a pedidos ya guardados (`--restaurar` deshace una ejecución anterior). |
| `.gitignore` | Excluye informes, capturas y backups del robot. |

**v7 queda aparcado.** No se sube ni se aplica.

---

## 4. En TU PC (después de que yo haga push)

En la terminal, en la raíz del proyecto
(`C:\Users\Marku\Desktop\PROYECTOS-IA\CineStock-Pedidos\claude-prueba\Pedidos-Conway`):

```
git fetch origin
git pull origin arena/67d0fffb-pedidos-conway
python "src\comprobar_version_robot.py"
```

Debe decir: **`v6b (la buena: anota el error y SIGUE)`**.

> Si `git pull` da conflicto porque tu `main` local tiene cambios de otra
> sesión, NO hagas merge. Usa la forma selectiva (trae solo los archivos de
> esta rama sin tocar tu historial):
>
> ```
> git fetch origin
> git checkout origin/arena/67d0fffb-pedidos-conway -- .gitignore src/robot_erp.py src/receptor.py src/ui/catalogo.py src/catalogo_erp.py src/recursos/correcciones_erp.json src/regenerar_pedido.py "src/comprobar version robot.py" src/comprobar_version_robot.py "src/aplicar parche v5.py" "src/aplicar parche v6b.py" "src/devolver v6.py" docs/INSTRUCCIONES_CINESTOCK.md
> git reset
> ```

El `.env` NO se toca: ya lo tienes con `ERP_USER` / `ERP_PASS`. Nunca se sube.

### Regenerar el pedido de 100 líneas

**Si ya ejecutaste `regenerar_pedido.py` ANTES del arreglo de la tarde**
(es decir, si su salida mencionaba Kit Kat Normal o Skittle Frutas), ejecuta
primero esto para deshacer esos dos cambios:

```
python src\regenerar_pedido.py --restaurar
```

`--restaurar` recupera la copia `.bak_*` más reciente de cada pedido y vuelve
a aplicar **solo las correcciones buenas**. Si es la primera vez, basta con:

```
python src\regenerar_pedido.py
```

Esto corrige `data/pedido_actual.json` y el archivo más reciente de
`data/pedidos_para_procesar/`, guardando una copia `.bak_<fecha>` de cada uno.
Te imprimirá línea por línea lo que cambia. **Pégame ese texto antes de lanzar
el robot.** Deben salir exactamente **3 líneas por archivo**:

```
(CI) Bolsa Asa Papel      1003020091 / IAH -> 1003020091 / ICG
(CI) Cuchara Madera       1003020087 / IDV -> 1003020096 / GDE
(CI) Tapa Vaso Mediana    1003020030 / GDE -> 1003020030 / CJA
```

> No intentes reenviar el mismo pedido desde el móvil: el receptor lo ignora
> por `orderId` duplicado. Para eso existe `regenerar_pedido.py`.

---

## 5. Antes de lanzar el robot (REGLA DE ORO)

Mientras el robot trabaja (10–15 min):

* ✅ Portátil **ABIERTO** (no bajar la tapa).
* ✅ **Con cable** de corriente.
* ✅ NO tocar Chrome, NO cerrar la consola negra.
* ✅ Mejor dejar el móvil y el ERP tranquilos hasta que acabe.

Lo de bajar la tapa fue exactamente lo que mató Chrome en la fila 33 del
último informe.

---

## 5 bis. ✅ Luz verde para el pedido de 100 líneas (27/10/2026, 17:47)

Salida verificada de `python src\regenerar_pedido.py --restaurar`:

* `v6b (la buena: anota el error y SIGUE)` en el comprobador.
* Restaurados los DOS archivos desde `*.bak_20261027_171149`.
* **Solo 3 líneas corregidas por archivo** (26 Bolsa Asa Papel, 28 Cuchara
  Madera, 29 Tapa Vaso Mediana). `TOTAL: 6`.
* Familias intactas: `Kit Kat (2): .../GBC, .../HSI`, `Skittle (2): .../HWC,
  .../HWD`, `Estuchado (3)`, `Haribo (8)`. Es decir, las dos UM que se habían
  estropeado por la mañana (`HSI` y `HWD`) están de vuelta.

### Antes de lanzar: verificar el JSON (OBLIGATORIO)

```
python src\verificar_pedido.py
```

Para el **pedido real de 146 líneas** (u otro archivo), pásale la ruta y el
nº de líneas:

```
python src\verificar_pedido.py "data\pedidos_para_procesar\pedido_146.json" --lineas 146
```

`src/verificar_pedido.py` es **solo de lectura**: busca las **5 correcciones por
NOMBRE** (no por nº de línea, así sirve para cualquier pedido), comprueba el
nº de líneas, que la Tapa Infantil sigue intacta y que las familias conservan
sus UM. Debe acabar con **`RESULTADO: TODO OK`**.
Si dice `PROBLEMA`, **no lances el robot**: ejecuta
`python src\regenerar_pedido.py --restaurar` y vuelve a verificar.

Motivo: el 27/10/2026 a las 14:29 se lanzó una carrera con el JSON **todavía
sin corregir** (informe `src/errores_pedido_20261027_143749.txt`). En su tabla
se veía `línea 26 / IAH`, `línea 28 / 1003020087 / IDV`, `línea 29 / GDE`.
Además, pulsar «Enviar a ERP» desde la pestaña **Pedidos** de CineStock
reescribe el JSON desde la memoria y puede borrar las correcciones. La
verificación lo detecta antes de perder 10–15 minutos.

### Comando exacto para lanzar el pedido de 100 líneas

Desde la **raíz del proyecto**, con el `.env` ya creado:

```
python src\robot_erp.py "data\pedidos_para_procesar\pedido_FLOW-1793107796283.json" --auto
```

Antes, comprobar que ese Python tiene selenium (debe decir `OK`):

```
python -c "import selenium, pandas; print('OK')"
```

Si no dice `OK`, lanzarlo desde CineStock → **Registro de Pedidos** → elegir
el pedido → **📤 Enviar a ERP** (esa pantalla usa el Python del programa).
**No usar la pestaña «Pedidos» para reenviar**: reconstruye el archivo desde
lo que tenga en memoria y podría perder las correcciones.

Al arrancar debe decir **`100 líneas a cargar`**. Incidencias esperadas en el
informe: línea 26 (UM `ICG` pendiente de confirmar), línea 30 (Tapa Infantil,
ya no existe). El robot **NO pulsa Guardar**; se revisa el informe antes.

---

## 6. Después de la carrera

1. El robot genera `src/errores_pedido_<fecha>.txt` y
   `src/pantalla_pedido_<fecha>.png`.
2. **Revisamos juntas el informe ANTES de que pulses Guardar.**
3. Si la fila 26 (Bolsa Asa Papel) vuelve a dar "UM no válida", es que `ICG`
   no vale para `1003020091`: abre la lupa del campo `*UM` en el ERP y dime
   qué UMs acepta.
4. La fila 30 (Tapa Infantil) aparecerá como incidencia real. Es esperado:
   el artículo ya no existe. Decidimos dejarla.
5. Cuando el informe esté claro, **pulsas Guardar tú** en el ERP.

---

## 7. En el PC DEL CINE

👉 **Si ya hay WinPython instalado (caso real): `docs/ACTUALIZACION_PC_CINE_HOY.md`.**
El ZIP `ACTUALIZACION_CINE.zip` lleva **los dos días**: menú Inicio con IA
(26/10) + robot v6c y correcciones ERP (27/10). Solo copia archivos.

👉 Instalación desde cero: `docs/INSTRUCCIONES_PC_CINE.md`.

Resumen (todos los comandos dentro de la carpeta del proyecto):

```
git fetch origin
git checkout origin/arena/67d0fffb-pedidos-conway -- <lista de archivos de la guía>
git reset
python -m pip install -r requirements.txt
python src\comprobar_instalacion.py
herramientas\arrancar_cinestock.bat
```

Puntos clave:

1. `python src\comprobar_version_robot.py` → debe decir **`v6c`**.
2. Crear **a mano** su `.env` en la raíz (NUNCA por Git):
   `ERP_USER`, `ERP_PASS` y, si procede, `OPENAI_API_KEY`.
3. Copiar por USB `data/supermaestro.json` y `data/supermaestro_flow.json`:
   `data/` está en `.gitignore` y no viaja por Git. Las **correcciones ERP sí
   viajan** en `src/recursos/correcciones_erp.json`.
4. `python src\comprobar_instalacion.py` debe acabar en **TODO OK**.
5. Arrancar con `herramientas\arrancar_cinestock.bat`.
   **NO usar `dist\CineStock\CineStock.exe`**: es una compilación antigua sin
   los arreglos.
6. Receptor en el puerto **8765**; comprobar `http://127.0.0.1:8765/ping` y
   después desde el móvil con la IP del PC (misma wifi/VPN, firewall abierto).

---

## 8. Copias de seguridad (27/10/2026)

**NO usar el típico `.bat` de «backup automático» que hace
`git add .` + `git pull origin main` + `git push origin main`.** Motivos:

1. Empuja a **`main`**, no a `arena/67d0fffb-pedidos-conway`. Mezclaría los
   cambios locales de otra sesión con la rama de trabajo.
2. `git pull origin main --no-rebase` puede crear un **merge con conflictos**
   y el `.bat` sigue hasta el `push` igualmente (no comprueba errores).
3. `.env` y `data/` están en `.gitignore`, pero un `git add .` **sí subiría**
   `dist/` (más de 100 MB entre `CineStock.exe` y sus DLL) y `build/`.
4. Si `.env` llegó a estar rastreado en algún momento, `.gitignore` **ya no lo
   protege** (`git add .` lo seguiría incluyendo).
5. `git add .` también podría colar informes, capturas o experimentos v7.

**Lo que ya está a salvo:** todo el código importante (robot v6b,
correcciones, receptor, regenerador, documentación) está subido en la rama
`arena/67d0fffb-pedidos-conway`. No hace falta ningún script para eso.

**Lo que NO está en GitHub, y NO debe estarlo:** `data/` (pedidos, catálogo,
copias `.bak_*`) y `.env` (credenciales). Para eso existe
**`herramientas/copia_seguridad_local.bat`**: crea un ZIP fechado en
`C:\Users\Marku\Desktop\BACKUPS-CineStock` **solo en el PC**, sin tocar Git.
Es seguro ejecutarlo incluso justo antes de una carrera del robot.

> Recordatorio: el `.env` del PC del cine se crea **a mano** y nunca se sube.

---

## 9. ✅ Carrera REAL de 100 líneas — 27/10/2026, 18:55 — OBJETIVO CONSEGUIDO

Informe: `src/errores_pedido_20261027_185530.txt`
Captura: `src/pantalla_pedido_20261027_185530.png`

**Resultado: 90 de 100 líneas sin incidencias, 10 con problemas.**
Chrome **NO** se cerró. v6b anotó cada fallo y **SIGUIÓ hasta la línea 100**.
Comparación con la carrera de las 14:29 (la del JSON viejo): 28/100 → 90/100.

### Lo que salió bien

* Las **3 correcciones ERP se aceptaron**: las líneas **26, 28 y 29 NO**
  aparecen en la lista de problemas.
* En particular **`1003020091 / ICG` (Bolsa Asa Papel) queda CONFIRMADO por el
  ERP**. Ya no está pendiente: se ha actualizado `correcciones_erp.json` a
  `CONFIRMADO_ERP`.
* Las familias (Kit Kat `HSI`, Skittle `HWD`, Haribo, Estuchados, Kojak) no
  dieron ni un problema.
* La línea 30 (Tapa Infantil) dio el error **esperado**: decisión «LA DEJAMOS».

### Las 10 incidencias

| Línea | Artículo | Motivo | Tipo |
|---|---|---|---|
| 30 | `1003020031 / IDZ` (CI) Tapa Vaso Pequeña/Infantil | El ERP no reconoce el artículo | **ESPERADA**, se deja |
| 38 | `1005010028 / HUM` Piruleta Corazon | El ERP no reconoce el artículo | código nuevo a buscar con la lupa |
| 43 | `1001010014 / IEH` Carton Palomitas XXL | El ERP no acepta la UM `IEH` | UM nueva a buscar con la lupa de `*UM` |
| 93 | `1001050004 / GAE` Goma Granel 1Kg.Huevos | No cargó la descripción | sospecha de falso positivo |
| 94 | `1001050004 / GEJ` Haribo Pasta Bas.Fresa.Pic | No se quedó escrito | sospecha de falso positivo |
| 95 | `1001050004 / GGC` Dragibus Bolsa 2 Kilos | No se quedó escrito | sospecha de falso positivo |
| 96 | `1001050004 / HBJ` Lagartones Bolsa 1 Kilo | No cargó la descripción | sospecha de falso positivo |
| 98 | `1001050002 / GFX` Twix Minix 2,5 kg | No cargó la descripción | sospecha de falso positivo |
| 99 | `1001050002 / HCG` Almendra California Blanca | No cargó la descripción | sospecha de falso positivo |
| 100 | `1001050002 / HCH` Almendra California Leche | No cargó la descripción | sospecha de falso positivo |

Cantidad de las 7 últimas: **2** en todas.

### ✅ Datos correctos encontrados en el ERP a las 19:17 (Búsqueda Art)

La encargada abrió «Búsqueda Art» y obtuvo los códigos/UM reales:

| Línea | Venía | **Correcto (ERP)** | Descripción que devuelve el ERP |
|---|---|---|---|
| 38 | `1005010028 / HUM` | **`1001040022 / HYR`** | Fiesta Piruleta Corazon Caja 80 Piezas |
| 43 | `1001010014 / IEH` | **`1001010014 / GEI`** | Carton Palomitas XXL Caja 160 Piezas Estuche Extra Grande |
| 93 | `1001050004 / GAE` | **ya era correcto** | Goma Granel 1Kg Huevos |
| 94 | `1001050004 / GEJ` | **ya era correcto** | Haribo Pasta Bas.Fresa.Pic Caja 1,72 Kilos |
| 95 | `1001050004 / GGC` | **ya era correcto** | Dragibus Bolsa 2 Kilos |
| 96 | `1001050004 / HBJ` | **ya era correcto** | Lagartones Bolsa 1 Kilo |
| 98 | `1001050002 / GFX` | **ya era correcto** | Twix Minix 2,5 kg |
| 99 | `1001050002 / HCG` | **ya era correcto** | Almendra California Blanca Bolsa 1 Kilo |
| 100 | `1001050002 / HCH` | **ya era correcto** | Almendra California Leche Bolsa 1 Kilo |

**Los 7 códigos/UM del final son BUENOS**: el ERP cargó todas sus
descripciones en la pantalla de búsqueda. Falló la **lectura del robot**, no
el dato. En `src/robot_erp.py`, `leer_descripcion()` lee por la posición `$i`
del DOM; con el grid paginado al final ese índice se descoloca, el robot no
consigue leer la descripción y **él mismo vacía la línea** (`vaciar()`).
Prueba: las líneas **92** (`1001050004 / GAD`) y **97** (`1001050004 / HBM`),
con el mismo código, sí están rellenas en la captura.

Las **2 correcciones nuevas** se han añadido a
`src/recursos/correcciones_erp.json` con `COINCIDENCIA=POR_NOMBRE` (no tienen
`ID VISTA` conocido, se buscan comparando el nombre del producto).
`src/verificar_pedido.py` ya comprueba las **5** correcciones (26, 28, 29,
38, 43).

**Sobre las variantes de Fiesta Piruleta Corazon:** la encargada confirma que
tiene **2 hijos (uno azul)**, pero como **solo se pide uno**, **NO** se mete en
`FAMILIAS_PROTEGIDAS`. Para que eso sea seguro, la corrección por nombre es
**estricta**: exige exactamente las mismas palabras (`_mismo_nombre_exacto`).
Si algún día aparece el hijo azul con otro nombre, no se le aplicará esta
corrección y el verificador lo avisará; habría que dar de alta su propio
código/UM.

**Línea 30:** la encargada confirmó a las 19:17 que la **Tapa Vaso Pequeña/
Infantil ya NO EXISTE en el ERP**. Se deja vacía. Antes del pedido de 146
líneas hay que retirar ese producto del catálogo de Flow/CineStock.

> 🔴 **NO SE HA PULSADO GUARDAR.** Revisar con la encargada antes. El vigilante
> del ID de Solicitud está esperando en la consola negra: no cerrarla.

---

## 10. v6c — el robot avisa qué PRODUCTOS fallan, con su CÓDIGO ERP

A petición de la encargada, `src/robot_erp.py` pasa a **v6c**. **No es la v7**:
es exactamente la **v6b aprobada** más tres cambios pequeños.

1. **Mensaje final y ventana flotante** incluyen una lista
   `PRODUCTOS QUE HAN DADO ERROR (con su CÓDIGO ERP)` con, para cada línea:
   número de fila, **código ERP**, UM, descripción del producto y motivo.
   Antes la ventana flotante solo decía «hay N incidencias» y había que abrir
   el `.txt`. También aparece al principio del informe `errores_pedido_*.txt`.
2. **No borra líneas buenas.** Cuando el grid paginado no deja leer la
   descripción pero el código **sí quedó escrito**, la línea se CONSERVA y
   solo se avisa. En v6b se vaciaba: por eso se perdieron las líneas 93, 96,
   98, 99 y 100 del test (códigos correctos). Si el código NO quedó escrito,
   se sigue vaciando como antes.
3. `src/comprobar version robot.py` reconoce **v6c**.

Ejemplo de lo que se ve ahora en la ventana flotante:

```
PRODUCTOS QUE HAN DADO ERROR (CÓDIGO ERP)
==========================================================================
  Fila  30 | CODIGO ERP: 1003020031 | UM: IDZ | (CI) Tapa Vaso Pequeña/Infantil
           -> El ERP no reconoce el artículo (Valor no válido)
  Fila  38 | CODIGO ERP: 1005010028 | UM: HUM | Piruleta Corazon
           -> El ERP no reconoce el artículo (Valor no válido)
==========================================================================
```

### Botón de deshacer

Si prefieres volver a la **v6b exacta**, ejecuta:

```
python "src\devolver v6b.py"
```

Guarda antes tu v6c como `src/robot_erp.py.bak_v6c_<fecha>` y restaura la
copia `src/recursos/robot_erp_v6b_original.py.txt`. Comprueba después con
`python src\comprobar_version_robot.py`.

> La **Tapa Infantil NO se filtra**: decidimos dejarla («LA DEJAMOS»). Ahora
> aparecerá claramente en la lista de la ventana flotante con su código
> `1003020031`, así siempre sabrás qué producto falta. Para el pedido real de
> 146 lo limpio es retirar ese producto del catálogo de Flow/CineStock.

### Un solo comando para traer TODO al PC

En PowerShell, en la raíz del proyecto:

```
git fetch origin
git checkout origin/arena/67d0fffb-pedidos-conway -- .gitignore src/robot_erp.py src/receptor.py src/ui/catalogo.py src/catalogo_erp.py src/recursos/correcciones_erp.json "src/recursos/robot_erp_v6b_original.py.txt" src/regenerar_pedido.py src/verificar_pedido.py "src/comprobar version robot.py" src/comprobar_version_robot.py "src/aplicar parche v5.py" "src/aplicar parche v6b.py" "src/devolver v6.py" "src/devolver v6b.py" docs/INSTRUCCIONES_CINESTOCK.md herramientas/copia_seguridad_local.bat
git reset
python src\comprobar_version_robot.py
```

Debe decir **`v6c`**.

---

## 11. Pendiente (mejora futura, tarea 6)

Validar en CineStock, antes de pulsar «Enviar a ERP», que cada `idErp` y cada
`umErp` existen en el catálogo y que el artículo no esté marcado como
`NO_EXISTE_EN_ERP`. Así una UM inválida nunca llegaría al ERP.

Tarea nueva surgida de la carrera de las 18:55: investigar por qué
`leer_descripcion()` falla en las últimas líneas del grid paginado; mientras
tanto, esas líneas se corrigen a mano en el ERP antes de Guardar.
