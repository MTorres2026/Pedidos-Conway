@echo off
chcp 65001 >nul
title CineStock - Comprobar instalacion
cd /d "%~dp0.."
if exist "herramientas\comprobar_instalacion.bat" (
  call "herramientas\comprobar_instalacion.bat"
) else (
  echo ERROR: falta herramientas\comprobar_instalacion.bat
  echo Ejecuta primero APLICAR.bat
  pause
)
